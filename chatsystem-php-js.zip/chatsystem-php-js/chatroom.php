<?php
if(!($_POST["name"] && $_POST["pwd"]=='123456'))
{
	header("Location: ./index.html");

}

?>


<!DOCTYPE html>
<html>
<head>
	<title>LetsChat</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<script src="js/jquery.js" type="text/javascript"></script>
	<style type="text/css">
	h1
	{	
	color:white;
	background: orange;
	border:1px solid black;
	font-weight: bold;
	border-radius: 10px;
	width:900px;
	}
	* {margin:0;padding:0;box-sizing:border-box;font-family:arial,sans-serif;resize:none;}
	html,body {width:100%;height:100%;}
	#wrapper {position:relative;margin:auto;max-width:1000px;height:100%;}
	#chat_output {position:absolute;top:0;left:0;padding:20px;width:100%;height:calc(100%-100px);}
	#chat_input {position:absolute;bottom:0;left:0;padding:10px;width:100%;height:100px;border:1px solid #ccc;}
	</style>
</head>
<body>
	<h1>welcome to Narsingi buddies <?php echo $_POST["name"]; ?></h1>
	<a>
	<div id="wrapper">
		<div id="chat_output"></div>
		<textarea  id="chat_input" placeholder="type your message and press enter..."></textarea>
		<script type="text/javascript">
		jQuery(function($){
			// Websocket
			var websocket_server = new WebSocket("ws://localhost:8080/");//////////////////////here
			websocket_server.onopen = function(e) {
				websocket_server.send(
					JSON.stringify({
						'type':'socket',
						'user_id':'<?php echo $_POST["name"]; ?>'
					})
				);
			};
			websocket_server.onerror = function(e) {
				// Errorhandling
				window.alert("///**Connection Error**///");
			}
			websocket_server.onmessage = function(e)
			{
				var json = JSON.parse(e.data);
				switch(json.type) {
					case 'chat':
						$('#chat_output').append(json.msg);
						break;
				}
			}
			// Events
			$('#chat_input').on('keyup',function(e){
				if(e.keyCode==13 )//&& !e.shiftKey
				{
					var chat_msg = $(this).val();
					websocket_server.send(
						JSON.stringify({
							'type':'chat',
							'user_id':'<?php echo $_POST["name"]; ?>',
							'chat_msg':chat_msg
						})
					);
					$(this).val('');
				}
			});
		});
		</script>
	</div>
</body>
</html>